package com.lamerman;

public class SelectionMode {
	public static final int MODE_CREATE = 0;

	public static final int MODE_OPEN = 1;
}
